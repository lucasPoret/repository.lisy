# <span style="color:red">A faire</span>

- [x] ne pas cherger tous les lien des cmd lors du chargement de la liste des vos mais seulement lorsque le vod est choisi

- [x] Setting most video properties through ListItem.setInfo() is deprecated and might be removed in future Kodi versions. Please use the respective setter in InfoTagVideo.




# <span style="color:orange">Pas urgent</span>
- [x] télchercher les icons
- [ ] mettre toutes les fonction dans un autres fichier pour rendre plus lisible et plus bo
- [x] ajouter la possibilité de voir les infos sur le média avec le click droit
# <span style="color:rgb(139, 128, 0)"> Si vraiment chui chaud </span>
- [ ] ajouter un système de cache 

